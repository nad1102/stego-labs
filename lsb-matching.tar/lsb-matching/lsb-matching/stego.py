import wave
import numpy as np
import os


def makeAudio(samples, nchannels, sampwidth, framerate):
    """Create a WAV file from samples."""
    output_file = "encrypted_audio.wav"
    try:
        wav_file = wave.open(output_file, "wb")
        wav_file.setnchannels(nchannels)
        wav_file.setsampwidth(sampwidth)
        wav_file.setframerate(framerate)
        wav_file.writeframes(samples.tobytes())
        wav_file.close()
        return output_file
    except Exception as e:
        print(f"Error writing WAV file: {e}")
        return None


def getTextFromFile(filename):
    """Read text from a file."""
    try:
        with open(filename, 'r') as file:
            return file.read()
    except FileNotFoundError:
        print(f"Text file {filename} not found.")
        return None
    except Exception as e:
        print(f"Error reading text file: {e}")
        return None


def getAudio(filename):
    """Read samples from a WAV file."""
    try:
        wav_file = wave.open(filename, 'rb')
        nchannels = wav_file.getnchannels()
        sampwidth = wav_file.getsampwidth()
        framerate = wav_file.getframerate()
        nframes = wav_file.getnframes()
        if sampwidth != 2:
            raise ValueError("Only 16-bit WAV files are supported.")
        samples = np.frombuffer(wav_file.readframes(nframes), dtype=np.int16)
        # Debug: Check sample range
        print(f"Input WAV: Max sample={samples.max()}, Min sample={samples.min()}")
        wav_file.close()
        return samples, nchannels, sampwidth, framerate
    except FileNotFoundError:
        print(f"Audio file {filename} not found.")
        return None, None, None, None
    except Exception as e:
        print(f"Error reading WAV file: {e}")
        return None, None, None, None


def putDataInSample(index, sixBinary, samples):
    """Embed 6 bits into a sample by modifying its 6 LSBs."""
    original = samples[index]
    try:
        binary_value = int(sixBinary, 2)
        if binary_value > 63:
            print(f"Invalid sixBinary at index {index}: {sixBinary}, value={binary_value}")
            binary_value = 63
    except ValueError:
        print(f"Invalid sixBinary format at index {index}: {sixBinary}")
        binary_value = 0

    # Convert to uint16 for safe bit operations
    temp_value = np.uint16(samples[index])
    temp_value = temp_value & 0xFFC0  # Clear 6 LSBs
    temp_value = temp_value | binary_value  # Set 6 LSBs
    # Convert back to int16
    new_value = np.int16(temp_value if temp_value <= 32767 else temp_value - 65536)
    # Clamp to ensure safety
    new_value = np.clip(new_value, -32768, 32767)
    # Debug: Print values (limit to first 10 indices)
    if index < 10:
        print(f"Index {index}: original={original}, after_bit_ops={temp_value}, final={new_value}, sixBinary={sixBinary}")
    # Assign to samples
    samples[index] = new_value

    # Verify
    if samples[index] < -32768 or samples[index] > 32767:
        print(f"Out of bounds at index {index}: original={original}, new={samples[index]}, sixBinary={sixBinary}")


def exportDataFromSample(index, samples):
    """Extract 6 bits from a sample's LSBs."""
    bits = bin(samples[index] & 0x3F)[2:]  # Get 6 LSBs
    bits = (6 - len(bits)) * "0" + bits  # Pad to 6 bits
    return bits


def stg(message, samples):
    """Embed message into audio samples."""
    messageLength = len(message)
    messageLengthBin = bin(messageLength)[2:]
    messageLengthBin = (24 - len(messageLengthBin)) * "0" + messageLengthBin
    sampleIndex = 0

    # Debug: Print message length
    print(f"Embedding message length: {messageLength} (binary: {messageLengthBin})")

    # Embed message length (24 bits) into first 4 samples (6 bits per sample)
    for i in range(0, 24, 6):
        putDataInSample(sampleIndex, messageLengthBin[i:i + 6], samples)
        sampleIndex += 1

    # Convert message to binary
    messageInBin = ""
    for char in message:
        binaryStr = bin(ord(char))[2:]
        binaryStr = (8 - len(binaryStr)) * "0" + binaryStr
        messageInBin += binaryStr
    # Pad to multiple of 6 at the end
    messageInBin += (6 - (len(messageInBin) % 6)) * "0"

    # Debug: Print message binary
    print(f"Message binary (padded): {messageInBin}")

    # Embed message
    for i in range(0, len(messageInBin), 6):
        putDataInSample(sampleIndex, messageInBin[i:i + 6], samples)
        sampleIndex += 1


def decrypt(samples):
    """Extract message from audio samples."""
    msgLenInBinary = ""
    # Extract message length from first 4 samples
    for ind in range(4):
        msgLenInBinary += exportDataFromSample(ind, samples)
    msgLen = int(msgLenInBinary, 2)

    # Debug: Print extracted length
    print(f"Extracted message length: {msgLen} (binary: {msgLenInBinary})")

    # Calculate number of bits for message
    numCheckingBits = msgLen * 8
    secretMsgInBinary = ""
    # Extract message bits
    samples_needed = (numCheckingBits + 5) // 6  # Ceiling division
    for i in range(4, 4 + samples_needed):
        secretMsgInBinary += exportDataFromSample(i, samples)

    # Trim to exact number of bits
    secretMsgInBinary = secretMsgInBinary[:numCheckingBits]

    # Debug: Print extracted binary
    print(f"Extracted message binary: {secretMsgInBinary}")

    # Convert binary to text
    secretMsg = ""
    for j in range(0, numCheckingBits, 8):
        byte = secretMsgInBinary[j:j + 8]
        secretMsg += chr(int(byte, 2))
    return secretMsg


def main():
    print("Welcome!")
    print("1. Encrypt a message in an audio file.")
    print("2. Extract a message from an audio file.")
    print("3. Quit")
    while True:
        try:
            task_number = int(input("Enter number of your wanted task: "))
            if task_number == 1:
                audioName = input("Enter the audio file name (WAV), which you're gonna use: ")
                messageText = input("Enter the text file name, which you're gonna encrypt: ")
                messageText = getTextFromFile(messageText)
                if messageText is None:
                    continue
                samples, nchannels, sampwidth, framerate = getAudio(audioName)
                if samples is None:
                    continue

                # Ensure samples is int16
                samples = samples.astype(np.int16)
                # Check if enough samples
                required_samples = 4 + (len(messageText) * 8 + 5) // 6
                if len(samples) < required_samples:
                    print(f"Not enough samples in audio. Need at least {required_samples} samples.")
                    continue

                samples = samples.copy()  # Avoid modifying original
                stg(messageText, samples)
                output_file = makeAudio(samples, nchannels, sampwidth, framerate)
                if output_file is None:
                    continue
                itsPassword = input("Enter a password for your encrypted audio: ")
                with open("passwords.txt", "a") as newP:
                    newP.write(itsPassword + "\n")
                print(f"Encrypted audio saved as {output_file}")
            elif task_number == 2:
                audioName = input("Enter the audio file name (WAV), which you're gonna use: ")
                password = input("Enter the password (or press Enter to skip): ")
                if password:
                    try:
                        with open("passwords.txt", "r") as checkP:
                            lines = [line.strip() for line in checkP.readlines()]
                        if password not in lines:
                            print("Invalid password.")
                            continue
                    except FileNotFoundError:
                        print("Password file not found.")
                        continue
                samples, _, _, _ = getAudio(audioName)
                if samples is None:
                    continue
                # Ensure samples is int16
                samples = samples.astype(np.int16)
                theSecretMsg = decrypt(samples)
                output_file = audioName.replace(".wav", "_export.txt")
                with open(output_file, "w") as includingFile:
                    includingFile.write(theSecretMsg)
                print(f"Extracted message saved to {output_file}")
            elif task_number == 3:
                break
            else:
                print("Invalid task.")
        except ValueError:
            print("Please enter a valid number.")
        except Exception as e:
            print(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
