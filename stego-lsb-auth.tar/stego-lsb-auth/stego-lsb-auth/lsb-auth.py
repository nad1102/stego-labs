import wave
import numpy as np
import os


def makeAudio(samples, nchannels, sampwidth, framerate):
    """Create a WAV file from samples."""
    output_file = "encrypted_audio.wav"
    try:
        wav_file = wave.open(output_file, "wb")
        wav_file.setnchannels(nchannels)
        wav_file.setsampwidth(sampwidth)
        wav_file.setframerate(framerate)
        wav_file.writeframes(samples.tobytes())
        wav_file.close()
        return output_file
    except Exception as e:
        print(f"Error writing WAV file: {e}")
        return None


def getTextFromFile(filename):
    """Read text from a file."""
    try:
        with open(filename, 'r') as file:
            return file.read()
    except FileNotFoundError:
        print(f"Text file {filename} not found.")
        return None
    except Exception as e:
        print(f"Error reading text file: {e}")
        return None


def getAudio(filename):
    """Read samples from a WAV file."""
    try:
        wav_file = wave.open(filename, 'rb')
        nchannels = wav_file.getnchannels()
        sampwidth = wav_file.getsampwidth()
        framerate = wav_file.getframerate()
        nframes = wav_file.getnframes()
        if sampwidth != 2:
            raise ValueError("Only 16-bit WAV files are supported.")
        samples = np.frombuffer(wav_file.readframes(nframes), dtype=np.int16)
        wav_file.close()
        return samples, nchannels, sampwidth, framerate
    except FileNotFoundError:
        print(f"Audio file {filename} not found.")
        return None, None, None, None
    except Exception as e:
        print(f"Error reading WAV file: {e}")
        return None, None, None, None


def putDataInSample(index, sixBinary, samples):
    """Embed 6 bits into a sample by modifying its 6 LSBs."""
    try:
        binary_value = int(sixBinary, 2)
        if binary_value > 63:
            binary_value = 63
    except ValueError:
        binary_value = 0

    temp_value = np.uint16(samples[index])
    temp_value = temp_value & 0xFFC0
    temp_value = temp_value | binary_value
    new_value = np.int16(temp_value if temp_value <= 32767 else temp_value - 65536)
    new_value = np.clip(new_value, -32768, 32767)
    samples[index] = new_value


def exportDataFromSample(index, samples):
    """Extract 6 bits from a sample's LSBs."""
    bits = bin(samples[index] & 0x3F)[2:]
    bits = (6 - len(bits)) * "0" + bits
    return bits


def stg(message, samples):
    """Embed message into audio samples."""
    messageLength = len(message)
    messageLengthBin = bin(messageLength)[2:]
    messageLengthBin = (24 - len(messageLengthBin)) * "0" + messageLengthBin
    sampleIndex = 0

    for i in range(0, 24, 6):
        putDataInSample(sampleIndex, messageLengthBin[i:i + 6], samples)
        sampleIndex += 1

    messageInBin = ""
    for char in message:
        binaryStr = bin(ord(char))[2:]
        binaryStr = (8 - len(binaryStr)) * "0" + binaryStr
        messageInBin += binaryStr
    messageInBin += (6 - (len(messageInBin) % 6)) * "0"

    for i in range(0, len(messageInBin), 6):
        putDataInSample(sampleIndex, messageInBin[i:i + 6], samples)
        sampleIndex += 1


def decrypt(samples):
    """Extract message from audio samples."""
    msgLenInBinary = ""
    for ind in range(4):
        msgLenInBinary += exportDataFromSample(ind, samples)
    msgLen = int(msgLenInBinary, 2)

    print(f"Extracted message length: {msgLen} (binary: {msgLenInBinary})")

    numCheckingBits = msgLen * 8
    secretMsgInBinary = ""
    samples_needed = (numCheckingBits + 5) // 6
    for i in range(4, 4 + samples_needed):
        secretMsgInBinary += exportDataFromSample(i, samples)

    secretMsgInBinary = secretMsgInBinary[:numCheckingBits]

    print(f"Extracted message binary: {secretMsgInBinary}")

    secretMsg = ""
    for j in range(0, numCheckingBits, 8):
        byte = secretMsgInBinary[j:j + 8]
        secretMsg += chr(int(byte, 2))
    return secretMsg


def main():
    try:
        # Encryption
        audioName = input("Enter the audio file name (WAV), which you're gonna encrypt: ")
        messageText = input("Enter the text file name, which you're gonna encrypt: ")
        messageText = getTextFromFile(messageText)
        if messageText is None:
            return
        samples, nchannels, sampwidth, framerate = getAudio(audioName)
        if samples is None:
            return

        samples = samples.astype(np.int16)
        required_samples = 4 + (len(messageText) * 8 + 5) // 6
        if len(samples) < required_samples:
            print(f"Not enough samples in audio. Need at least {required_samples} samples.")
            return

        while True:
            itsPassword = input("Enter a password for your encrypted audio: ")
            if itsPassword:
                break
            print("Password cannot be empty.")

        samples = samples.copy()
        stg(messageText, samples)
        output_file = makeAudio(samples, nchannels, sampwidth, framerate)
        if output_file is None:
            return
        with open("passwords.txt", "w") as newP:
            newP.write(itsPassword + "\n")
        print(f"Encrypted audio saved as {output_file}")

        # Decryption
        audioName = input("Enter the audio file name (WAV), which you're gonna decrypt: ")
        while True:
            password = input("Enter the password: ")
            if not password:
                print("Password cannot be empty.")
                continue
            try:
                with open("passwords.txt", "r") as checkP:
                    saved_password = checkP.read().strip()
                if password != saved_password:
                    print("Invalid password.")
                    continue
                break
            except FileNotFoundError:
                print("Password file not found.")
                return

        samples, _, _, _ = getAudio(audioName)
        if samples is None:
            return
        samples = samples.astype(np.int16)
        theSecretMsg = decrypt(samples)
        output_file = audioName.replace(".wav", "_export.txt")
        with open(output_file, "w") as includingFile:
            includingFile.write(theSecretMsg)
        print(f"Extracted message saved to {output_file}")

    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
