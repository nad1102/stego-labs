import wave
import numpy as np
import matplotlib.pyplot as plt
import os


def read_wav(filename):
    """Read samples from a WAV file."""
    try:
        wav_file = wave.open(filename, 'rb')
        nchannels = wav_file.getnchannels()
        sampwidth = wav_file.getsampwidth()
        framerate = wav_file.getframerate()
        nframes = wav_file.getnframes()
        if sampwidth != 2:
            raise ValueError("Only 16-bit WAV files are supported.")
        samples = np.frombuffer(wav_file.readframes(nframes), dtype=np.int16)
        wav_file.close()
        return samples, nchannels, sampwidth, framerate
    except FileNotFoundError:
        print(f"Audio file {filename} not found.")
        return None, None, None, None
    except Exception as e:
        print(f"Error reading WAV file: {e}")
        return None, None, None, None


def extract_lsb(samples):
    """Extract 6 LSBs from each sample."""
    return samples & 0x3F  # Get 6 LSBs (values from 0 to 63)


def analyze_files(file1, file2):
    """Analyze two WAV files for steganography with improved visualization."""
    # Read files
    samples1, nchannels1, sampwidth1, framerate1 = read_wav(file1)
    samples2, nchannels2, sampwidth2, framerate2 = read_wav(file2)
    
    if samples1 is None or samples2 is None:
        return
    
    # Check compatibility
    if (nchannels1 != nchannels2 or sampwidth1 != sampwidth2 or 
        framerate1 != framerate2 or len(samples1) != len(samples2)):
        print("Files are not compatible (different channels, sample width, framerate, or length).")
        return
    
    # Extract LSBs
    lsb1 = extract_lsb(samples1)
    lsb2 = extract_lsb(samples2)
    
    # Calculate sample differences
    diff = samples2 - samples1  # Difference between samples
    
    # Count modified samples
    modified_samples = np.sum(diff != 0)
    total_samples = len(samples1)
    modified_percentage = (modified_samples / total_samples) * 100
    
    # Create histograms
    plt.figure(figsize=(12, 10))
    
    # Histogram of LSB values (first 1000 samples to focus on stego region)
    plt.subplot(2, 1, 1)
    plt.hist(lsb1[:1000], bins=64, range=(0, 64), alpha=0.5, label=os.path.basename(file1), color='blue', density=True)
    plt.hist(lsb2[:1000], bins=64, range=(0, 64), alpha=0.5, label=os.path.basename(file2), color='red', density=True)
    plt.title(f'LSB Distribution (First 1000 Samples): {os.path.basename(file1)} vs {os.path.basename(file2)}')
    plt.xlabel('LSB Value (0 to 63)')
    plt.ylabel('Normalized Frequency')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.ylim(0, 0.1)  # Limit y-axis to make differences visible
    
    # Histogram of sample differences (excluding zero to highlight changes)
    non_zero_diff = diff[diff != 0]
    plt.subplot(2, 1, 2)
    if len(non_zero_diff) > 0:
        plt.hist(non_zero_diff, bins=127, range=(-63.5, 63.5), color='green', density=True)
        plt.title(f'Sample Differences (Non-Zero): {os.path.basename(file2)} - {os.path.basename(file1)}')
    else:
        plt.text(0.5, 0.5, 'No differences detected', horizontalalignment='center', verticalalignment='center')
        plt.title(f'Sample Differences: {os.path.basename(file2)} - {os.path.basename(file1)}')
    plt.xlabel('Difference Value')
    plt.ylabel('Normalized Frequency')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('stego_analysis_improved.png')
    plt.close()
    
    # Conclusion
    print(f"Analysis Results:")
    print(f"- Total samples: {total_samples}")
    print(f"- Modified samples: {modified_samples} ({modified_percentage:.2f}%)")
    
    # Calculate LSB entropy
    def calculate_entropy(data):
        counts, _ = np.histogram(data, bins=64, range=(0, 64), density=True)
        entropy = -np.sum([p * np.log2(p + 1e-10) for p in counts if p > 0])
        return entropy
    
    entropy1 = calculate_entropy(lsb1)
    entropy2 = calculate_entropy(lsb2)
    print(f"- LSB Entropy ({os.path.basename(file1)}): {entropy1:.2f} bits")
    print(f"- LSB Entropy ({os.path.basename(file2)}): {entropy2:.2f} bits")
    
    # Determine which file is stego
    if modified_samples > 0:
        print(f"\nConclusion: {os.path.basename(file2)} is likely the stego file (contains hidden data).")
        print(f"Reason: {modified_samples} samples differ, indicating LSB modifications.")
    else:
        print(f"\nConclusion: No clear evidence of steganography.")
        print(f"Reason: No sample differences detected.")


def main():
    file1 = input("Enter the first WAV file (original): ")
    file2 = input("Enter the second WAV file (potentially stego): ")
    analyze_files(file1, file2)


if __name__ == "__main__":
    main()
